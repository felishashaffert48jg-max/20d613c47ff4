// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Roll up parquet files\n", stdout);
  return lionss_run_workload("ParquetRollup");
}
