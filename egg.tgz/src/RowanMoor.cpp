// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Generate rowan moor\n", stdout);
  return lionss_run_workload("RowanMoor");
}
