// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render coverage heatmap"); }
int main(){
  announce();
  return lionss_run_workload("coverageHeatmap");
}
