// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sort Pareto fronts"); }
int main(){
  announce();
  return lionss_run_workload("nsga2_front");
}
