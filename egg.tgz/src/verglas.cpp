// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Form verglas coating\n", stdout);
  return lionss_run_workload("verglas");
}
